An Alexa skill for getting when the next train is. 

Uses AWS Lambda + alexa-sdk + tfnsw API. A basic wrapper for TFNSW API is included. 
